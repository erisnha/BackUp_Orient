package com.newgen.ServiceProcess;

import static com.newgen.OrientAP.Head.disablefield;
import com.newgen.bapi.taxcode_list;
import java.util.HashMap;
import java.util.List;
import javax.faces.validator.ValidatorException;

import com.newgen.common.General;
import static com.newgen.common.General.convertNewgenDateToSapDate;
import com.newgen.common.PicklistListenerHandler;
import com.newgen.common.WFXmlList;
import com.newgen.common.WFXmlResponse;
import com.newgen.common.XMLParser;

import com.newgen.omniforms.FormConfig;
import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.component.IRepeater;
import com.newgen.omniforms.component.ListView;
import com.newgen.omniforms.component.PickList;
import com.newgen.omniforms.context.FormContext;
import com.newgen.omniforms.event.ComponentEvent;
import com.newgen.omniforms.event.FormEvent;
import com.newgen.omniforms.listener.FormListener;
import java.awt.Color;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import javax.faces.application.FacesMessage;

public class Head implements FormListener {

    //FormReference objFormReference = null; //FormContext.getCurrentInstance().getFormReference();
    FormReference formObject = null;
    FormConfig formConfig = null;
    String activityName = null;
    String engineName = null;
    String sessionId = null;
    String folderId = null;
    String FILE = null;
    String serverUrl = null;
    String processInstanceId = null;
    String workItemId = null;
    String userName = null;
    String processDefId = null;
    String Query, mail_query = null;
    List<List<String>> result, result1;
    PickList objPicklist;
    General objGeneral = null;
    private String today;
    XMLParser xmlParser = new XMLParser();
    private String activityId;
    setPODetails objsetpodetails = null;
    private String today1;
    private int difference;
    private List<List<String>> resultarray;
    private int fiscalYear;
    taxcode_list objtaxcode_list = null;

    @Override
    public void continueExecution(String arg0, HashMap<String, String> arg1) {
        // TODO Auto-generated method stub
    }

    @Override
    public void eventDispatched(ComponentEvent pEvent) throws ValidatorException {
        formObject = FormContext.getCurrentInstance().getFormReference();
        formConfig = FormContext.getCurrentInstance().getFormConfig();
        objGeneral = new General();
        objsetpodetails = new setPODetails();
        if (pEvent.getType().name().equalsIgnoreCase("VALUE_CHANGED")) {
            if (pEvent.getSource().getName().equalsIgnoreCase("PurchaseOrderNo")) {
                System.out.println("Inside value change PurchaseOrderNo");
                String inputXml = objGeneral.sapInvokeXML("BAPI_PO_GETDETAIL");
                inputXml = inputXml + "<Parameters>"
                        + "<ImportParameters>"
                        + "<PURCHASEORDER>" + formObject.getNGValue("PurchaseOrderNo") + "</PURCHASEORDER>"
                        + "<HISTORY>X</HISTORY>"
                        + "<SERVICES>X</SERVICES>"
                        + "</ImportParameters>"
                        + "</Parameters>"
                        + "</WFSAPInvokeFunction_Input>";
                System.out.println("Input xml : " + inputXml);
                String outputXml = objGeneral.executeWithCallBroker(inputXml, processInstanceId + "_BAPI_PO_GETDETAIL");
                System.out.println("Output XML : " + outputXml);
                xmlParser.setInputXML(outputXml);
                WFXmlResponse objXmlResponse = new WFXmlResponse(outputXml);
                int x = 0;
                if (xmlParser.getValueOf("MainCode").equalsIgnoreCase("0")) {
                    String attributes = "", xmlnew = "", complex_po_item_history = "",
                            complex_orient_entry_service = "", complex_orient_po_item = "";

                    formObject.setNGValue("comp_code", xmlParser.getValueOf("CO_CODE"));
                    formObject.setNGValue("PoDate", objGeneral.convertSapDateToNewgenDate(xmlParser.getValueOf("CREATED_ON")));
                    formObject.setNGValue("po_type", xmlParser.getValueOf("DOC_TYPE"));
                    formObject.setNGValue("pur_group", xmlParser.getValueOf("PUR_GROUP"));
                    formObject.setNGValue("pur_org", xmlParser.getValueOf("PURCH_ORG"));
                    formObject.setNGValue("vendor_code", xmlParser.getValueOf("VENDOR"));
                    formObject.setNGValue("vendor_name", xmlParser.getValueOf("VEND_NAME"));
                    formObject.setNGValue("currency", xmlParser.getValueOf("CURRENCY"));

                    formObject.clear("EntrySheetNo");

                    Query = "Delete from complex_orient_po_item where pinstanceid = '" + processInstanceId + "'";
                    formObject.saveDataIntoDataSource(Query);

                    Query = "Delete from complex_orient_poitem_history where pinstanceid = '" + processInstanceId + "'";
                    formObject.saveDataIntoDataSource(Query);

                    Query = "Delete from complex_orient_entry_service where pinstanceid = '" + processInstanceId + "'";
                    formObject.saveDataIntoDataSource(Query);

                    String assignAttribute = "<WFSetAttributes_Input><Option>WFSetAttributes</Option>"
                            + "<EngineName>" + engineName + "</EngineName>"
                            + "<SessionId>" + sessionId + "</SessionId>"
                            + "<UserDefVarFlag>Y</UserDefVarFlag>"
                            + "<ProcessDefId>" + processDefId + "</ProcessDefId>"
                            + "<ActivityId>" + activityId + "</ActivityId>"
                            + "<ProcessInstanceId>" + processInstanceId + "</ProcessInstanceId>"
                            + "<WorkitemId>1</WorkitemId>"
                            + "<Attributes>";

                    for (WFXmlList objList = objXmlResponse.createList("TableParameters", "PO_ITEMS"); objList.hasMoreElements(); objList.skip()) {
                        complex_orient_po_item = complex_orient_po_item
                                + "<q_orient_po_item>"
                                + objList.getVal("PO_ITEMS")
                                + "</q_orient_po_item>";

                    }

                    for (WFXmlList objList = objXmlResponse.createList("TableParameters", "PO_ITEM_HISTORY"); objList.hasMoreElements(); objList.skip()) {
                        complex_po_item_history = complex_po_item_history
                                + "<q_orient_poitem_history>"
                                + objList.getVal("PO_ITEM_HISTORY")
                                + "</q_orient_poitem_history>";
                    }

                    for (WFXmlList objList = objXmlResponse.createList("TableParameters", "PO_ITEM_SERVICES"); objList.hasMoreElements(); objList.skip()) {
                        complex_orient_entry_service = complex_orient_entry_service
                                + "<q_orient_entry_service>"
                                + objList.getVal("PO_ITEM_SERVICES")
                                + "</q_orient_entry_service>";
                    }

                    assignAttribute = assignAttribute
                            + complex_orient_po_item
                            + complex_po_item_history
                            + complex_orient_entry_service
                            + "</Attributes></WFSetAttributes_Input>";
                    outputXml = objGeneral.executeWithCallBroker(assignAttribute, processInstanceId + "_WFSetAttributes");

                    if (activityName.equalsIgnoreCase("ServiceUpload")) {
                        Query = "select MAT_DOC from complex_orient_poitem_history where pinstanceid = '" + processInstanceId + "' "
                                + "and HIST_TYPE = 'D'";
                        System.out.println("Query : " + Query);
                        result = formObject.getDataFromDataSource(Query);

                        for (int i = 0; i < result.size(); i++) {
                            Query = "select * from complex_orient_poitem_history where "
                                    + "pinstanceid = '" + processInstanceId + "' and HIST_TYPE not in ('D' , 'E') "
                                    + "and REF_DOC = '" + result.get(i).get(0) + "'";
                            System.out.println("Query : " + Query);
                            result1 = formObject.getDataFromDataSource(Query);
                            if (result1.isEmpty()) {
                                System.out.println("Inside result1 empty");
                                formObject.addItem("EntrySheetNo", result.get(i).get(0));
                            }
                        }
                    } else {
                        Query = "select EntrySheetNo from ext_serviceprocess where processid = '" + processInstanceId + "'";
                        result1 = formObject.getDataFromDataSource(Query);
                        formObject.addItem("EntrySheetNo", result1.get(0).get(0));
                    }
                    System.out.println("Before PO Line");
                    objsetpodetails.setPOLine();

                    Query = "select distinct PLANT from complex_orient_po_item "
                            + "where pinstanceid = '" + formConfig.getConfigElement("ProcessInstanceId") + "'";
                    System.out.println("Query for profit center : " + Query);
                    List<List<String>> result = formObject.getDataFromDataSource(Query);
                    String Plant = result.get(0).get(0);
                    int plant_int = Integer.parseInt(Plant);

                    String vendor_code = formObject.getNGValue("vendor_code");
                    String orient_code = "P" + plant_int;

                    String vendorGSTN = objGeneral.getVendorGSTN(vendor_code);
                    System.out.println("Vendor GSTN : " + vendorGSTN);
                    formObject.setNGValue("gstn_sap", vendorGSTN);
                    formObject.setNGValue("GSTN", vendorGSTN);

                    String orientGSTN = objGeneral.getVendorGSTN(orient_code);
                    System.out.println("Orient GSTN : " + orientGSTN);
                    formObject.setNGValue("orient_gstn", orientGSTN);
                    formObject.setNGValue("gstn_inv", orientGSTN);

                    String vendorPAN = objGeneral.getVendorPAN(vendor_code);
                    System.out.println("Vendor PAN : " + vendorPAN);
                    formObject.setNGValue("pan_sap", vendorPAN);
                    formObject.setNGValue("PAN", vendorPAN);

                    String orientPAN = objGeneral.getVendorPAN(orient_code);
                    System.out.println("Orient PAN : " + orientPAN);
                    formObject.setNGValue("orient_PAN", orientPAN);
                    formObject.setNGValue("pan_inv", orientPAN);
//                    System.out.println("Before Entry Line");
//                    objsetpodetails.setEntryLine();
                }

            }
            if (pEvent.getSource().getName().equalsIgnoreCase("EntrySheetNo")) {
                System.out.println("Inside entrysheet value change");
                //   objsetpodetails.setEntryLine();
            }

            if (pEvent.getSource().getName().equalsIgnoreCase("service_status")) {
                System.out.println("Inside value change service_status");
                String status_val = formObject.getNGValue("service_status");
                System.out.println("Status value : " + status_val);

                if ("Approve".equalsIgnoreCase(status_val)) {
                    System.out.println("Inside approve");
                    formObject.setVisible("route_to", false);
                } else {
                    System.out.println("Inside reject");
                    formObject.setVisible("route_to", true);
                    formObject.clear("route_to");
                    if (activityName.equalsIgnoreCase("Level1")) {
                        formObject.addComboItem("route_to", "Previous Stage", "Previous Stage");
                    } else if (activityName.equalsIgnoreCase("Level2")) {
                        formObject.addComboItem("route_to", "Level1", "Level1");
                    } else if (activityName.equalsIgnoreCase("Level3")) {
                        formObject.addComboItem("route_to", "Level1", "Level1");
                        formObject.addComboItem("route_to", "Level2", "Level2");
                    } else if (activityName.equalsIgnoreCase("Level4")) {
                        formObject.addComboItem("route_to", "Level1", "Level1");
                        formObject.addComboItem("route_to", "Level2", "Level2");
                        formObject.addComboItem("route_to", "Level3", "Level3");
                    } else if (activityName.equalsIgnoreCase("Service Correction")) {
                        formObject.setVisible("route_to", false);
                        formObject.setEnabled("service_status", false);
                    }

                }

            }
        }

        if (pEvent.getType().name().equalsIgnoreCase("MOUSE_CLICKED")) {
            System.out.print("------------Inside Mouse Click------------------");

            if (pEvent.getSource().getName().equalsIgnoreCase("Button22")) {

                String entrysheetno = formObject.getNGValue("EntrySheetNo");
                ListView lv0 = (ListView) formObject.getComponent("q_orient_entrysheet_sel");
                int rowcount = lv0.getRowCount();
                System.out.println("Row count : " + rowcount);
                if (rowcount > 0) {
                    for (int i = 0; i < rowcount; i++) {
                        if (entrysheetno.equalsIgnoreCase(formObject.getNGValue("q_orient_entrysheet_sel", i, 0))) {
                            throw new ValidatorException(new FacesMessage("Entry Sheet no already added.", ""));
                        } else {
                            formObject.ExecuteExternalCommand("NGAddRow", "q_orient_entrysheet_sel");
                            objsetpodetails.setPoTotal(entrysheetno);
                        }
                    }
                } else {
                    formObject.ExecuteExternalCommand("NGAddRow", "q_orient_entrysheet_sel");
                    objsetpodetails.setPoTotal(entrysheetno);
                }

            }

            if (pEvent.getSource().getName().equalsIgnoreCase("Button2")) {
                formObject.ExecuteExternalCommand("NGDeleteRow", "ListView3");
            }

            if (pEvent.getSource().getName().equalsIgnoreCase("Button1")) {
                System.out.println("Inside Button 16");
                int count = 0;
                String drop_val = formObject.getNGValue("Combo1");
                ListView lv1 = (ListView) formObject.getComponent("ListView3");
                int lvRowCount = lv1.getRowCount();
                //add for loop to iterate list view.
                for (int x = 0; x < lvRowCount; x++) {
                    //if list view description matched with combo item exit
                    String desc = formObject.getNGValue("ListView3", x, 4);
                    System.out.println(desc + " <==> " + drop_val);
                    if (desc.equalsIgnoreCase(drop_val)) {
                        System.out.println("Increasing Count");
                        count++;
                        break;
                    }
                }

                if (count == 0) {
                    System.out.println("Inside Count");
                    String inputXml = objGeneral.sapInvokeXML("ZBAPI_AP_AUTOMATION_TDS");
                    inputXml = inputXml + "<Parameters>"
                            + "<ImportParameters>"
                            + "<VENDOR>" + formObject.getNGValue("vendor_code") + "</VENDOR>"
                            + "<COMP_CODE>1000</COMP_CODE>"
                            + "</ImportParameters>"
                            + "</Parameters>"
                            + "</WFSAPInvokeFunction_Input>";
                    String outputXml = objGeneral.executeWithCallBroker(inputXml, processInstanceId + "_ZBAPI_AP_AUTOMATION_TDS");
                    xmlParser.setInputXML(outputXml);
                    WFXmlResponse objXmlResponse = new WFXmlResponse(outputXml);
                    // System.out.println("After xml response outputxml : " + outputXml);
                    if (xmlParser.getValueOf("MainCode").equalsIgnoreCase("0")) {

                        String xmlnew = "";
                        for (WFXmlList objList = objXmlResponse.createList("TableParameters", "TDS_TAB"); objList.hasMoreElements(); objList.skip()) {
                            String DESC = objList.getVal("DESC");
                            String COUNTRY = objList.getVal("COUNTRY");
                            String WITHT = objList.getVal("WITHT");
                            String WT_WITHCD = objList.getVal("WT_WITHCD");
                            String QSATZ = objList.getVal("QSATZ");

                            if (DESC.equalsIgnoreCase(drop_val)) {

                                xmlnew = xmlnew + "<ListItem><SubItem>" + COUNTRY
                                        + "</SubItem><SubItem>" + WITHT
                                        + "</SubItem><SubItem>" + WT_WITHCD
                                        + "</SubItem><SubItem>" + QSATZ
                                        + "</SubItem><SubItem>" + DESC
                                        + "</SubItem></ListItem>";

                                System.out.println("XML : " + xmlnew);
                                formObject.NGAddListItem("ListView3", xmlnew);
                            }
                        }
                    }
                } else {
                    throw new ValidatorException(new FacesMessage("Already exist.", ""));

                }
            }

            if (pEvent.getSource().getName().equalsIgnoreCase("Button3")) {

                objtaxcode_list = new taxcode_list();
                List<List<String>> taxList = new ArrayList<List<String>>();
                try {
                    objPicklist = formObject.getNGPickList("taxcode_service", "Tax Code,Description", true, 100);
                    Color color = new Color(31, 98, 171);
                    objPicklist.setPicklistHeaderBGColor(color);
                    objPicklist.setPicklistHeaderFGColor(Color.WHITE);
                    objPicklist.setWindowTitle("Tax code list");
                    objPicklist.setWidth(200);
                    objPicklist.setHeight(550);
                    objPicklist.addPickListListener(new PicklistListenerHandler(objPicklist.getClientId()));
                    String inputXml = objtaxcode_list.getTAX_CODE_LIST();
                    String outputXml = objGeneral.executeWithCallBroker(inputXml, processInstanceId + "_ZBAPI_AP_AUTOMATION_TAX_CODE");
                    xmlParser.setInputXML(outputXml);
                    WFXmlResponse objXmlResponse = new WFXmlResponse(outputXml);
                    System.out.println("After xml response");
                    if (xmlParser.getValueOf("MainCode").equalsIgnoreCase("0")) {
                        for (WFXmlList objList = objXmlResponse.createList("TableParameters", "TAX_TAB"); objList.hasMoreElements(); objList.skip()) {
                            System.out.println("Inside TAX_CODE loop");
                            String TAX_CODE = objList.getVal("TAX_CODE");
                            System.out.println("TAX CODE : " + TAX_CODE);
                            String DESC = objList.getVal("DESC");
                            System.out.println("DESC : " + DESC);
                            taxList.add(Arrays.asList(TAX_CODE, DESC));
                        }
                    }
                    objPicklist.populateData(taxList);
                    objPicklist.setVisible(true);
                    System.out.println("###Populate data");
                } catch (Exception e) {
                    System.out.println("Exception in FieldValueBagSet::::" + e.getMessage());
                }
            }

            if (pEvent.getSource().getName().equalsIgnoreCase("Button5")) {
                System.out.println("Inside button click 5");
                int temp_doc_item = 0;
                String SRV_BASED_IV = "", busPlc_val = "", itemdata_ser = "", inv_doc_item = "", poitem1;
                String invoiceno = formObject.getNGValue("InvoiceNo");
                String inputXml = objGeneral.sapInvokeXML("BAPI_PO_GETDETAIL1");
                inputXml = inputXml + "<Parameters>"
                        + "<ImportParameters>"
                        + "<PURCHASEORDER>" + formObject.getNGValue("PurchaseOrderNo") + "</PURCHASEORDER>"
                        + "</ImportParameters>"
                        + "</Parameters>"
                        + "</WFSAPInvokeFunction_Input>";
                System.out.println("Input xml : " + inputXml);
                String outputXml = objGeneral.executeWithCallBroker(inputXml, processInstanceId + "_BAPI_PO_GETDETAIL1");
                xmlParser.setInputXML(outputXml);
                WFXmlResponse objXmlResponse = new WFXmlResponse(outputXml);
                if (xmlParser.getValueOf("MainCode").equalsIgnoreCase("0")) {
                    for (WFXmlList objList = objXmlResponse.createList("TableParameters", "POITEM"); objList.hasMoreElements(); objList.skip()) {
                        SRV_BASED_IV = objList.getVal("SRV_BASED_IV");
                        System.out.println("SRV_BASED_IV Value : " + SRV_BASED_IV);
                    }
                }

                Query = "select distinct plant from complex_orient_po_item where pinstanceid = '" + processInstanceId + "'";
                String inputXml1 = objGeneral.sapInvokeXML("ZBAPI_AP_AUTOMATION_BUSPLACE");
                inputXml1 = inputXml1 + "<Parameters>"
                        + "<ImportParameters>"
                        + "<PLANT>" + formObject.getDataFromDataSource(Query).get(0).get(0) + "</PLANT>"
                        + "</ImportParameters>"
                        + "</Parameters>"
                        + "</WFSAPInvokeFunction_Input>";
                System.out.println("Input XML : " + inputXml1);
                String outputXml1 = objGeneral.executeWithCallBroker(inputXml1, processInstanceId + "_ZBAPI_AP_AUTOMATION_BUSPLACE");
                xmlParser.setInputXML(outputXml1);
                WFXmlResponse objXmlResponse1 = new WFXmlResponse(outputXml1);
                System.out.println("After xml response");
                if (xmlParser.getValueOf("MainCode").equalsIgnoreCase("0")) {
                    busPlc_val = xmlParser.getValueOf("BUSS_PLACE");
                } else {
                    busPlc_val = "";
                }

                ListView lv1 = (ListView) formObject.getComponent("q_orient_entrysheet_sel");
                int rowcount = lv1.getRowCount();
                System.out.println("Row count Entrysheet: " + rowcount);
                for (int k = 0; k < rowcount; k++) {
                    //Service PO parking  ------------------------------------------------------
                    Query = "Select PO_ITEM,REF_DOC_YR,REF_DOC_IT,VAL_LOCCUR,REF_DOC,QUANTITY "
                            + "from complex_orient_poitem_history where pinstanceid = '" + processInstanceId + "' "
                            + "and HIST_TYPE = 'E' "
                            + "and REF_DOC = '" + formObject.getNGValue("q_orient_entrysheet_sel", k, 0) + "'";
                    System.out.println("Query : " + Query);
                    result = formObject.getDataFromDataSource(Query);
                    String LVPOname = "q_orient_poitem_history";
                    int latest = 0;
                    for (int i = 0; i < result.size(); i++) {
                        //  if (invoiceno.equalsIgnoreCase(formObject.getNGValue(LVPOname, i, 0))) {
                        temp_doc_item = temp_doc_item + 1;
                        latest = i;
                        difference = 6 - String.valueOf(temp_doc_item).length();
                        if (difference > 0) {
                            inv_doc_item = String.format("%0" + (difference) + "d%s", 0, String.valueOf(temp_doc_item));
                        } else {
                            inv_doc_item = String.valueOf(temp_doc_item);
                        }

                        String po_item_temp1 = result.get(i).get(0);
                        difference = 5 - po_item_temp1.length();
                        if (difference > 0) {
                            poitem1 = String.format("%0" + (5 - po_item_temp1.length()) + "d%s", 0, po_item_temp1);

                        } else {
                            poitem1 = formObject.getNGValue(LVPOname, latest, 7);
                        }

                        //***********************************************************//
                        String po_unit_iso = "", sheet_item = "", OUTL_IND = "";
                        Query = "select UOM_ISO,OUTL_IND from complex_orient_entry_service where "
                                + "pinstanceid='" + processInstanceId + "' "
                                + "and EXT_LINE = '" + po_item_temp1 + "'";
                        System.out.println("Query itemdata : " + Query);
                        resultarray = formObject.getDataFromDataSource(Query);
                        System.out.println("Result size : " + resultarray.size());
                        if (resultarray.size() > 0) {
                            System.out.println("Inside result > 0");
                            po_unit_iso = resultarray.get(0).get(0);
                            System.out.println("po_unit_iso " + po_unit_iso);
                            OUTL_IND = resultarray.get(0).get(1);
                            System.out.println("OUTL_IND " + OUTL_IND);
                            if ("X".equalsIgnoreCase(OUTL_IND)) {
                                sheet_item = "";
                            } else {
                                System.out.println("Inside else");
                                sheet_item = po_item_temp1;
                            }
                        }
                        System.out.println("Sheet Item : " + sheet_item);
                        // String po_unit = resultarray.get(0).get(1);
                        // String taxcode = resultarray.get(0).get(2);

                        //***********************************************************//
                        itemdata_ser = itemdata_ser + "<ITEMDATA>"
                                + "<INVOICE_DOC_ITEM>" + inv_doc_item + "</INVOICE_DOC_ITEM>"
                                + "<PO_NUMBER>" + formObject.getNGValue("PurchaseOrderNo") + "</PO_NUMBER>"
                                + "<PO_ITEM>" + poitem1 + "</PO_ITEM>"
                                + "<REF_DOC_YEAR>" + result.get(i).get(1) + "</REF_DOC_YEAR>"
                                + "<REF_DOC_IT>" + result.get(i).get(2) + "</REF_DOC_IT>"
                                + "<ITEM_AMOUNT>" + result.get(i).get(3) + "</ITEM_AMOUNT>"
                                + "<SHEET_NO>" + result.get(i).get(4) + "</SHEET_NO>"
                                + "<SHEET_ITEM>" + sheet_item + "</SHEET_ITEM>";

                        if (SRV_BASED_IV.equalsIgnoreCase("X")) {
                            System.out.println("Inside SRV_BASED_IV == 'X'");

                            Query = "select TAX_CODE from complex_orient_po_item where "
                                    + "pinstanceid = '" + formConfig.getConfigElement("ProcessInstanceId") + "' "
                                    + "and PO_ITEM in (select PO_ITEM from complex_orient_poitem_history "
                                    + "where pinstanceid = '" + formConfig.getConfigElement("ProcessInstanceId") + "' "
                                    + "and MAT_DOC = '" + formObject.getNGValue("q_orient_entrysheet_sel", k, 0) + "') ";
                            System.out.println("Query fot item PO " + Query);
                            result1 = formObject.getDataFromDataSource(Query);
//                            System.out.println("Result size : " + result.size() + " - Tax Code value :" + result.get(0).get(0));
//                            formObject.setNGValue("taxcode_service", result.get(0).get(0));

                            itemdata_ser = itemdata_ser + "<PO_UNIT_ISO>" + po_unit_iso + "</PO_UNIT_ISO>"
                                    // + "<PO_UNIT>" + po_unit + "</PO_UNIT>"
                                    + "<TAX_CODE>" + result1.get(0).get(0) + "</TAX_CODE>"
                                    + "<QUANTITY>" + result.get(i).get(5) + "</QUANTITY>"
                                    + "</ITEMDATA>";
                        } else {
                            System.out.println("Inside SRV_BASED_IV != 'X'");
                            itemdata_ser = itemdata_ser + "<PO_UNIT_ISO></PO_UNIT_ISO>"
                                    // + "<PO_UNIT>" + po_unit + "</PO_UNIT>"
                                    // + "<TAX_CODE>" + taxcode + "</TAX_CODE>"
                                    + "<QUANTITY></QUANTITY>"
                                    + "</ITEMDATA>";
                        }
                        System.out.println("Outside SRV_BASED_IV X");
                        //  }
                    }
                    System.out.println("Outside for 2");
                }
                System.out.println("Item Data service : " + itemdata_ser);
                String LVControlName = "ListView3";
                ListView lv0 = (ListView) formObject.getComponent(LVControlName);
                int lvRowCount = lv0.getRowCount();
                System.out.println("Row count : " + lvRowCount);
                String withholdingtax = "";

                float totalAmount = 0f;
                BigDecimal decimal = null;
                for (int j = 0; j < result.size(); j++) {
                    totalAmount = totalAmount + Float.parseFloat(result.get(j).get(3));
                    System.out.println("Gross Value = " + result.get(j).get(3) + " Total = " + totalAmount);
                    decimal = new BigDecimal(totalAmount);
                    System.out.println("--" + decimal);
                }

                System.out.println("Line total is " + decimal);
                for (int i = 0; i < lvRowCount; i++) {
                    float wi_percent = Float.parseFloat(formObject.getNGValue(LVControlName, i, 3));
                    float wi_base_amount = (wi_percent / 100) * totalAmount;
                    withholdingtax = withholdingtax + "<WITHTAXDATA>"
                            + "<SPLIT_KEY>000001</SPLIT_KEY>"
                            + "<WI_TAX_TYPE>" + formObject.getNGValue(LVControlName, i, 1) + "</WI_TAX_TYPE>"
                            + "<WI_TAX_CODE>" + formObject.getNGValue(LVControlName, i, 2) + "</WI_TAX_CODE>"
                            + "<WI_TAX_BASE>" + decimal.setScale(2, BigDecimal.ROUND_FLOOR) + "</WI_TAX_BASE>"
                            + "<WI_TAX_AMT>" + Math.round(Math.ceil(wi_base_amount)) + "</WI_TAX_AMT>"
                            + "</WITHTAXDATA>";
                }
                //******WithHolding Tax********//

                System.out.println("Inv " + formObject.getNGValue("InvoiceDate"));
                System.out.println("Post " + formObject.getNGValue("posting_date"));
                String docdate = convertNewgenDateToSapDate(formObject.getNGValue("InvoiceDate"));
                String postingdate = convertNewgenDateToSapDate(formObject.getNGValue("posting_date"));
                System.out.println("date " + docdate + " " + postingdate);
                String currency = formObject.getNGValue("currency");
                System.out.println("Currency : " + currency);
                inputXml1 = "";
                inputXml1 = objGeneral.sapInvokeXML("BAPI_INCOMINGINVOICE_PARK");
                inputXml1 = inputXml1 + "<Parameters>"
                        + "<ImportParameters>"
                        + "<HEADERDATA>"
                        + "<INVOICE_IND>X</INVOICE_IND>"
                        + "<DOC_DATE>" + docdate + " 00:00:00.0</DOC_DATE>"
                        + "<PSTNG_DATE>" + postingdate + " 00:00:00.0</PSTNG_DATE>"
                        + "<REF_DOC_NO>" + invoiceno + "</REF_DOC_NO>"
                        + "<COMP_CODE>1000</COMP_CODE>"
                        + "<CURRENCY>" + currency + "</CURRENCY>"
                        + "<GROSS_AMOUNT>" + formObject.getNGValue("InvoiceAmount") + "</GROSS_AMOUNT>"
                        + "<HEADER_TXT>" + userName + "</HEADER_TXT>"
                        + "<BUSINESS_PLACE>" + busPlc_val + "</BUSINESS_PLACE>"
                        + "<CALC_TAX_IND>X</CALC_TAX_IND>"
                        + "</HEADERDATA>"
                        + "</ImportParameters>"
                        + "<TableParameters>"
                        + itemdata_ser
                        + withholdingtax
                        + "</TableParameters>"
                        + "</Parameters>"
                        + "</WFSAPInvokeFunction_Input>";
                System.out.println("Input : " + inputXml1);
                outputXml = objGeneral.executeWithCallBroker(inputXml1, processInstanceId + "_BAPI_INCOMINGINVOICE_PARK");
                xmlParser.setInputXML(outputXml);
                objXmlResponse = new WFXmlResponse(outputXml);
                System.out.println("After xml response");
                String INVOICEDOCNUMBER = "", message1 = "";

                if (xmlParser.getValueOf("MainCode").equalsIgnoreCase("0")) {
                    INVOICEDOCNUMBER = xmlParser.getValueOf("INVOICEDOCNUMBER");
                    System.out.println("Document no: " + INVOICEDOCNUMBER);
                    formObject.setNGValue("Inv_Park", INVOICEDOCNUMBER);

                    message1 = xmlParser.getValueOf("MESSAGE");
                    if ("".equalsIgnoreCase(INVOICEDOCNUMBER)) {
                        throw new ValidatorException(new FacesMessage("Error while parking: " + message1, ""));
                    } else {
                        formObject.RaiseEvent("WFSave");

                        throw new ValidatorException(new FacesMessage("Invoice Document Number :" + INVOICEDOCNUMBER, ""));
                    }

                } else {
                    throw new ValidatorException(new FacesMessage("Please Contact Your Administrator", ""));
                }
            }
        }
    }

    @Override
    public void formLoaded(FormEvent arg0) {
        // TODO Auto-generated method stub
        System.out.println(" -------------------Intiation Workstep Loaded from formloaded.----------------");
        // TODO Auto-generated method stub
        System.out.println("form Loaded called");
        formObject = FormContext.getCurrentInstance().getFormReference();
        formConfig = FormContext.getCurrentInstance().getFormConfig();
        System.out.println("formObject :" + formObject);
        System.out.println("formConfig :" + formConfig);
        try {
            //  System.out.println("-->>" + formConfig.getConfigXML());
            activityName = formObject.getWFActivityName();
            activityId = formConfig.getConfigElement("ActivityId");
            engineName = formConfig.getConfigElement("EngineName");
            sessionId = formConfig.getConfigElement("DMSSessionId");
            folderId = formConfig.getConfigElement("FolderId");
            serverUrl = formConfig.getConfigElement("ServletPath");
            //ServletUrl = serverUrl + "/servlet/ExternalServlet";
            processInstanceId = formConfig.getConfigElement("ProcessInstanceId");
            workItemId = formConfig.getConfigElement("WorkitemId");
            userName = formConfig.getConfigElement("UserName");
            processDefId = formConfig.getConfigElement("ProcessDefId");
//            System.out.println("ProcessInstanceId===== " + processInstanceId);
//            System.out.println("Activityname=====" + activityName);
//            System.out.println("CabinetName====" + engineName);
//            System.out.println("sessionId====" + sessionId);
//            System.out.println("Username====" + userName);
//            System.out.println("workItemId====" + workItemId);

//  ************************************************************************************
        } catch (Exception e) {
            System.out.println("Exception in FieldValueBagSet::::" + e.getMessage());
        }
    }

    @Override
    public void formPopulated(FormEvent arg0) {
        formObject = FormContext.getCurrentInstance().getFormReference();
        formConfig = FormContext.getCurrentInstance().getFormConfig();
        // TODO Auto-generated method stub     
        objGeneral = new General();
        objsetpodetails = new setPODetails();
        Date date = Calendar.getInstance().getTime();
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        fiscalYear = cal.get(Calendar.YEAR);
        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        DateFormat formatter1 = new SimpleDateFormat("dd/MM/yyyy");
        today = formatter1.format(date);
        today1 = formatter1.format(date);
        System.out.println("----------------------Intiation Workstep Loaded from form populated.---------------------------");

        if (activityName.equalsIgnoreCase("ServiceUpload")) {
            formObject.setVisible("Tab1", false);
            formObject.setSheetVisible("Tab2", 1, false);
            formObject.setSheetVisible("Tab2", 2, false);
            Query = "select wf.ProcessInstanceID,wf.ActivityName from ext_serviceprocess ext, WFINSTRUMENTTABLE wf "
                    + "where ext.processid = wf.ProcessInstanceID "
                    + " and ext.PurchaseOrderNo = '" + formObject.getNGValue("PurchaseOrderNo") + "' "
                    + " and ext.EntrySheetNo = '" + formObject.getNGValue("EntrySheetNo") + "'";
            result = formObject.getDataFromDataSource(Query);

            if (result.size() > 0) {
                throw new ValidatorException(new FacesMessage("The invoice for the Purchase order no. " + formObject.getNGValue("PurchaseOrderNo")
                        + " and Entry sheet no. " + formObject.getNGValue("EntrySheetNo") + " has been already processed.", ""));
            }
        }
        if (activityName.equalsIgnoreCase("Level1")
                || activityName.equalsIgnoreCase("Level2")
                || activityName.equalsIgnoreCase("Level3")
                || activityName.equalsIgnoreCase("Level4")
                || activityName.equalsIgnoreCase("Service Correction")) {
            formObject.setSheetVisible("Tab2", 2, false);
            formObject.setSheetVisible("Tab1", 1, false);
            formObject.setSheetVisible("Tab1", 2, false);
            formObject.setSheetVisible("Tab1", 3, false);
            formObject.setEnabled("PurchaseOrderNo", false);
            formObject.setEnabled("EntrySheetNo", false);
            formObject.setEnabled("InvoiceNo", false);
            formObject.setEnabled("InvoiceDate", false);
            formObject.setEnabled("InvoiceAmount", false);
            formObject.setEnabled("GSTN", false);
            formObject.setEnabled("gstn_inv", false);
            formObject.setEnabled("pan_inv", false);
            formObject.setEnabled("PAN", false);

            formObject.setVisible("EntrySheetNo", false);
            formObject.setVisible("Label4", false);
            formObject.setVisible("Button22", false);
            formObject.setVisible("Button6", false);

            objsetpodetails.setEntryLine();
            objsetpodetails.setPOLine();
        }

        if (activityName.equalsIgnoreCase("Accounts")) {

            formObject.setSheetEnable("Tab1", 0, false);
            formObject.setSheetVisible("Tab1", 2, false);
            formObject.setSheetVisible("Tab1", 3, false);
            formObject.setEnabled("PurchaseOrderNo", false);
            formObject.setEnabled("EntrySheetNo", false);

            formObject.setEnabled("GSTN", false);
            formObject.setEnabled("gstn_inv", false);
            formObject.setEnabled("pan_inv", false);
            formObject.setEnabled("PAN", false);

            formObject.setVisible("EntrySheetNo", false);
            formObject.setVisible("Label4", false);
            formObject.setVisible("Button22", false);
            formObject.setVisible("Button6", false);

            objsetpodetails.setPOLine();
            formObject.clear("ListView3");
            String inputXml = objGeneral.sapInvokeXML("ZBAPI_AP_AUTOMATION_TDS");
            inputXml = inputXml + "<Parameters>"
                    + "<ImportParameters>"
                    + "<VENDOR>" + formObject.getNGValue("vendor_code") + "</VENDOR>"
                    + "<COMP_CODE>1000</COMP_CODE>"
                    + "</ImportParameters>"
                    + "</Parameters>"
                    + "</WFSAPInvokeFunction_Input>";
            String outputXml = objGeneral.executeWithCallBroker(inputXml, processInstanceId + "_ZBAPI_AP_AUTOMATION_TDS");
            xmlParser.setInputXML(outputXml);
            WFXmlResponse objXmlResponse = new WFXmlResponse(outputXml);
            // System.out.println("After xml response outputxml : " + outputXml);
            if (xmlParser.getValueOf("MainCode").equalsIgnoreCase("0")) {

                String xmlnew = "";
                for (WFXmlList objList = objXmlResponse.createList("TableParameters", "TDS_TAB"); objList.hasMoreElements(); objList.skip()) {
                    String COUNTRY = objList.getVal("COUNTRY");
                    String WITHT = objList.getVal("WITHT");
                    String WT_WITHCD = objList.getVal("WT_WITHCD");
                    String QSATZ = objList.getVal("QSATZ");
                    String DESC = objList.getVal("DESC");

                    formObject.addItem("Combo1", DESC);

                    xmlnew = xmlnew + "<ListItem><SubItem>" + COUNTRY
                            + "</SubItem><SubItem>" + WITHT
                            + "</SubItem><SubItem>" + WT_WITHCD
                            + "</SubItem><SubItem>" + QSATZ
                            + "</SubItem><SubItem>" + DESC
                            + "</SubItem></ListItem>";
                }
                System.out.println("XML : " + xmlnew);
                formObject.NGAddListItem("ListView3", xmlnew);

            }

            objsetpodetails.setEntryLine();
        }

        if (activityName.equalsIgnoreCase("Finance")) {
            formObject.setSheetVisible("Tab2", 2, false);
            formObject.setSheetEnable("Tab1", 0, false);
            formObject.setSheetEnable("Tab1", 1, false);
            formObject.setSheetVisible("Tab1", 3, false);

            formObject.setVisible("Button4", false);

            formObject.setEnabled("PurchaseOrderNo", false);
            formObject.setEnabled("EntrySheetNo", false);

            formObject.setEnabled("GSTN", false);
            formObject.setEnabled("gstn_inv", false);
            formObject.setEnabled("pan_inv", false);
            formObject.setEnabled("PAN", false);

            formObject.setVisible("EntrySheetNo", false);
            formObject.setVisible("Label4", false);
            formObject.setVisible("Button22", false);
            formObject.setVisible("Button6", false);
            objsetpodetails.setPOLine();
            objsetpodetails.setEntryLine();
        }

    }

    @Override
    public void saveFormCompleted(FormEvent arg0) throws ValidatorException {
        // TODO Auto-generated method stub
        System.out.print("-------------------save form completed---------");
    }

    @Override
    public void saveFormStarted(FormEvent arg0) throws ValidatorException {
        // TODO Auto-generated method stub
        formObject = FormContext.getCurrentInstance().getFormReference();
        formConfig = FormContext.getCurrentInstance().getFormConfig();

    }

    @Override
    public void submitFormCompleted(FormEvent arg0) throws ValidatorException {
        // TODO Auto-generated method stub
        formObject = FormContext.getCurrentInstance().getFormReference();
        formConfig = FormContext.getCurrentInstance().getFormConfig();
    }

    @Override
    public void submitFormStarted(FormEvent arg0) throws ValidatorException {
        // TODO Auto-generated method stub
        formObject = FormContext.getCurrentInstance().getFormReference();
        formConfig = FormContext.getCurrentInstance().getFormConfig();
        String assignedTo = "";
        String inv_amount = formObject.getNGValue("InvoiceAmount");
        String purc_group = formObject.getNGValue("pur_group");
        String service_status = formObject.getNGValue("service_status");
        System.out.println("inv_amount" + inv_amount + "purc_group" + purc_group);
        String amount_status = objGeneral.setUserforDOA(inv_amount, purc_group);
        String route_to = formObject.getNGValue("route_to");

        if (amount_status.equalsIgnoreCase("")) {
            formObject.setNGValue("route_to", "Park");
        } else {
            if (activityName.equalsIgnoreCase("ServiceUpload")
                    || activityName.equalsIgnoreCase("Service Correction")) {

                Query = "select documentindex from pdbdocumentcontent "
                        + "where parentfolderindex"
                        + "= (select var_rec_1 from wfinstrumenttable "
                        + "where processinstanceid='" + processInstanceId + "')";
                System.out.println("Query for document " + Query);
                resultarray = formObject.getDataFromDataSource(Query);
                if (resultarray.size() <= 0) {
                    throw new ValidatorException(new FacesMessage("Please attach Invoice Document", ""));
                }

                Query = "select l1_userid from complex_orient_doa_usermapping where purch_group = '" + purc_group + "' and "
                        + "values_doa = '" + amount_status + "'";
                System.out.println("Query to assignedUser  ServiceEntry: " + Query);

            }

            if (activityName.equalsIgnoreCase("Level1")) {
                if ("Approve".equalsIgnoreCase(service_status)) {
                    Query = "select l2_userid from complex_orient_doa_usermapping where purch_group = '" + purc_group + "' and "
                            + "values_doa = '" + amount_status + "'";
                }
                if ("Reject".equalsIgnoreCase(service_status)) {
                    Query = "";
                }
                System.out.println("Query to assignedUser  L1: " + Query);
            }
            if (activityName.equalsIgnoreCase("Level2")) {
                if ("Approve".equalsIgnoreCase(service_status)) {
                    Query = "select l3_userid from complex_orient_doa_usermapping where purch_group = '" + purc_group + "' and "
                            + "values_doa = '" + amount_status + "'";
                }
                if ("Reject".equalsIgnoreCase(service_status)) {
                    Query = "select l1_userid from complex_orient_doa_usermapping where purch_group = '" + purc_group + "' and "
                            + "values_doa = '" + amount_status + "'";
                }
                System.out.println("Query to assignedUser  L2: " + Query);
            }
            if (activityName.equalsIgnoreCase("Level3")) {
                if ("Approve".equalsIgnoreCase(service_status)) {
                    Query = "select l4_userid from complex_orient_doa_usermapping where purch_group = '" + purc_group + "' and "
                            + "values_doa = '" + amount_status + "'";
                }
                if ("Reject".equalsIgnoreCase(service_status) && "Level1".equalsIgnoreCase(route_to)) {
                    Query = "select l1_userid from complex_orient_doa_usermapping where purch_group = '" + purc_group + "' and "
                            + "values_doa = '" + amount_status + "'";
                }
                if ("Reject".equalsIgnoreCase(service_status) && "Level2".equalsIgnoreCase(route_to)) {
                    Query = "select l2_userid from complex_orient_doa_usermapping where purch_group = '" + purc_group + "' and "
                            + "values_doa = '" + amount_status + "'";
                }
                System.out.println("Query to assignedUser  L3: " + Query);
            }

            if (activityName.equalsIgnoreCase("Level4")) {
                if ("Approve".equalsIgnoreCase(service_status)) {
                    Query = "";
                }
                if ("Reject".equalsIgnoreCase(service_status) && "Level1".equalsIgnoreCase(route_to)) {
                    Query = "select l1_userid from complex_orient_doa_usermapping where purch_group = '" + purc_group + "' and "
                            + "values_doa = '" + amount_status + "'";
                }
                if ("Reject".equalsIgnoreCase(service_status) && "Level2".equalsIgnoreCase(route_to)) {
                    Query = "select l2_userid from complex_orient_doa_usermapping where purch_group = '" + purc_group + "' and "
                            + "values_doa = '" + amount_status + "'";
                }
                if ("Reject".equalsIgnoreCase(service_status) && "Level3".equalsIgnoreCase(route_to)) {
                    Query = "select l3_userid from complex_orient_doa_usermapping where purch_group = '" + purc_group + "' and "
                            + "values_doa = '" + amount_status + "'";
                }
                System.out.println("Query to assignedUser  L4: " + Query);
            }

            if (!"".equalsIgnoreCase(Query)) {
                result = formObject.getDataFromDataSource(Query);
                assignedTo = result.get(0).get(0);
                System.out.println("Assigned User : " + assignedTo);
            }
            if (null == assignedTo
                    || "null".equalsIgnoreCase(assignedTo)
                    || "".equalsIgnoreCase(assignedTo)
                    || amount_status.equalsIgnoreCase("")) {
                formObject.setNGValue("route_to", "Park");
            }
        }
        formObject.setNGValue("assignedTo", assignedTo);
        String xmlnew = "";
        xmlnew = xmlnew + "<ListItem><SubItem>" + activityName
                + "</SubItem><SubItem>" + userName
                + "</SubItem><SubItem>" + today1
                + "</SubItem><SubItem>" + service_status
                + "</SubItem><SubItem>" + formObject.getNGValue("Text29")
                + "</SubItem></ListItem>";
        // // System.out.println("xml2 is" + xmlnew);
        System.out.println("q_serviceapproval XML : " + xmlnew);
        formObject.NGAddListItem("q_serviceapproval", xmlnew);
        formObject.clear("Text29");
    }

    @Override
    public void initialize() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public String encrypt(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String decrypt(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
